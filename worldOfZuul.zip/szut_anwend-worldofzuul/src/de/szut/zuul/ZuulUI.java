package de.szut.zuul;

public class ZuulUI {

    /**
     * @param args
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
}


